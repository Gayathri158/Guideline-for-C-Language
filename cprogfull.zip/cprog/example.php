 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="removechar.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>


                <div class="clearer"></div>
               <hr>
			   <h1> Examples </h1>
				<h2>C &quot;Hello, World!&quot; Program</h2>
 
<div class="page-short-description">
A simple C program to display "Hello, World!" on the screen. Since, it's a very simple program, 
it is often used to illustrate the syntax of a programming language.</div>
<div class="inside-content">
  <div class="region region-content-inside">
    <div id="block-block-43" class="block block-block">

    
</div>
  </div>
</div>
  <div class="region region-content">
    <div id="block-system-main" class="block block-system">

	
<pre>
<code>#include &lt;stdio.h&gt;
int main()
{
   // printf() displays the string inside quotation
   printf(&quot;Hello, World!&quot;);
   return 0;
}
</code></pre>

</div><p><strong>Output</strong></p>
<pre>
<samp>Hello, World!</samp></pre>
</div>
<hr>
<h2>Program to Print ASCII Value</h2>
<p>A character variable holds ASCII value (an integer number between 0 and 127) rather than that character itself in C programming. That value is known as ASCII value.</p>
<p><strong>For example</strong>, ASCII value of &#39;A&#39; is 65.</p>
<p>What this means is that, if you assign &#39;A&#39; to a character variable, 65 is stored in that variable rather than &#39;A&#39; itself.</p>

<pre>
<code>#include &lt;stdio.h&gt;
int main()
{
    char c;
    printf(&quot;Enter a character: &quot;);

    // Reads character input from the user
    scanf(&quot;%c&quot;, &amp;c);  
    
    // %d displays the integer value of a character
    // %c displays the actual character
    printf(&quot;ASCII value of %c = %d&quot;, c, c);
    return 0;
}
</code></pre>
<p><strong>Output</strong></p>
<pre>
Enter a character: G
ASCII value of G = 71
</pre>
			 <hr>
			 <h2>Find the Frequency of Characters</h2>
<p>In this program, user is asked to enter a character which is stored in variable <var>c.</var>&nbsp;The ASCII value of that character is stored in variable<var> c</var>&nbsp;rather than that variable itself.</p>
<p>When %d format string is used, 71 (ASCII value of &#39;G&#39;) is displayed.</p>
<p>When %c format string is used, &#39;G&#39; itself is displayed.</p>

<pre>
<code>#include &lt;stdio.h&gt;

int main()
{
   char str[1000], ch;
   int i, frequency = 0;

   printf(&quot;Enter a string: &quot;);
   gets(str);

   printf(&quot;Enter a character to find the frequency: &quot;);
   scanf(&quot;%c&quot;,&amp;ch);

   for(i = 0; str[i] != &#39;\0&#39;; ++i)
   {
       if(ch == str[i])
           ++frequency;
   }

   printf(&quot;Frequency of %c = %d&quot;, ch, frequency);

   return 0;
}
</code></pre>
<p><strong>Output</strong></p>
<pre>
<samp>Enter a string: This website is awesome.
Enter a character to find the frequency: e
Frequency of e = 4</samp></pre>
<p>In this program, the string entered by the user is stored in variable <var>str</var>.</p>
<p>Then, the user is asked to enter the character whose frequency is to be found. This is stored in variable <var>ch</var>.</p>
<p>Now, using the for loop, each character in the string is checked for the entered character.</p>
<p>If, the character is found, the <var>frequency</var> is increased. If not, the loop continues.</p>
<p>Finally, the frequency is printed.</p>

<hr>
<h2>Program to Check Alphabet</h2>

<div class="page-short-description">
In this example, you will learn to check whether a character entered by the user is an alphabet or not.</div>

<pre>
<code>#include &lt;stdio.h&gt;
int main()
{
    char c;
    printf(&quot;Enter a character: &quot;);
    scanf(&quot;%c&quot;,&amp;c);

    if( (c&gt;=&#39;a&#39; &amp;&amp; c&lt;=&#39;z&#39;) || (c&gt;=&#39;A&#39; &amp;&amp; c&lt;=&#39;Z&#39;))
        printf(&quot;%c is an alphabet.&quot;,c);
    else
        printf(&quot;%c is not an alphabet.&quot;,c);

    return 0;
}</code>
</pre>
<p><strong>Output </strong></p>
<pre>
<samp>Enter a character: *
* is not an alphabet</samp></pre>
<p>In C programming, a character variable holds ASCII value (an integer number between 0 and 127) rather than that character itself.</p>
<p>The ASCII value of lowercase alphabets are from 97 to 122. And, the ASCII value of uppercase alphabets are from 65 to 90.</p>
<p>If the ASCII value of the character entered by the user lies in the range from 97 to 122 or from 65 to 90, that number is an alphabet. In the program,&#39;a&#39; is used instead of 97 and &#39;z&#39; is used instead of 122. Similarly, &#39;A&#39; is used instead of 65 and &#39;Z&#39; is used instead of 90.</p>
<p>You can also check whether a character is an alphabet or not using <a href="/c-programming/library-function/ctype.h/isalpha" title="C isalpha() function">isalpha()</a> function.</p>
<hr>
<h2>Program to count vowels, consonants etc.</h2>

<div class="page-short-description">
This program counts the number of vowels, consonants, digits and white-spaces in a string which is entered by the user.</div>
<pre>
<code>#include &lt;stdio.h&gt;

int main()
{
    char line[150];
    int i, vowels, consonants, digits, spaces;

    vowels =  consonants = digits = spaces = 0;

    printf(&quot;Enter a line of string: &quot;);
    scanf(&quot;%[^\n]&quot;, line);

    for(i=0; line[i]!=&#39;\0&#39;; ++i)
    {
        if(line[i]==&#39;a&#39; || line[i]==&#39;e&#39; || line[i]==&#39;i&#39; ||
           line[i]==&#39;o&#39; || line[i]==&#39;u&#39; || line[i]==&#39;A&#39; ||
           line[i]==&#39;E&#39; || line[i]==&#39;I&#39; || line[i]==&#39;O&#39; ||
           line[i]==&#39;U&#39;)
        {
            ++vowels;
        }
        else if((line[i]&gt;=&#39;a&#39;&amp;&amp; line[i]&lt;=&#39;z&#39;) || (line[i]&gt;=&#39;A&#39;&amp;&amp; line[i]&lt;=&#39;Z&#39;))
        {
            ++consonants;
        }
        else if(line[i]&gt;=&#39;0&#39; &amp;&amp; line[i]&lt;=&#39;9&#39;)
        {
            ++digits;
        }
        else if (line[i]==&#39; &#39;)
        {
            ++spaces;
        }
    }

    printf(&quot;Vowels: %d&quot;,vowels);
    printf(&quot;\nConsonants: %d&quot;,consonants);
    printf(&quot;\nDigits: %d&quot;,digits);
    printf(&quot;\nWhite spaces: %d&quot;, spaces);

    return 0;
}
</code></pre>
<p><strong>Output</strong></p>
<pre>
<samp>Enter a line of string: adfslkj34 34lkj343 34lk
Vowels: 1
Consonants: 11
Digits: 9
White spaces: 2</samp></pre>
<p>This program takes string input from the user and stores in variable <var>line</var>.</p>
<p>Initially, the variables <var>vowels</var>, <var>consonants</var>, <var>digits</var> and <var>spaces</var> are initialized to 0.</p>
<p>When the vowel character is found, <var>vowel</var> variable is incremented by 1. Similarly, <var>consonants</var>, <var>digits</var> and <var>spaces</var> are incremented when these characters are found.</p>
<p>Finally, the count is displayed on the screen.</p>
<hr>
<h2>Armstrong Numbers Between Two Integers</h2>

<div class="page-short-description">
Example to find all Armstrong numbers between two integers (entered by the user) using loops and if...else statement.</div>
<pre>
<code>#include &lt;stdio.h&gt;
#include &lt;math.h&gt;

int main()
{
    int low, high, i, temp1, temp2, remainder, n = 0, result = 0;

    printf(&quot;Enter two numbers(intervals): &quot;);
    scanf(&quot;%d %d&quot;, &amp;low, &amp;high);
    printf(&quot;Armstrong numbers between %d an %d are: &quot;, low, high);

    for(i = low + 1; i &lt; high; ++i)
    {
        temp2 = i;
        temp1 = i;

        // number of digits calculation
        while (temp1 != 0)
        {
            temp1 /= 10;
            ++n;
        }

        // result contains sum of nth power of its digits
        while (temp2 != 0)
        {
            remainder = temp2 % 10;
            result += pow(remainder, n);
            temp2 /= 10;
        }

        // checks if number i is equal to the sum of nth power of its digits
        if (result == i) {
            printf(&quot;%d &quot;, i);
        }

        // resetting the values to check Armstrong number for next iteration
        n = 0;
        result = 0;

    }
    return 0;
}
</code></pre>
<p><b>Output</b></p>
<pre>
<samp>Enter two numbers(intervals): 999
99999
Armstrong numbers between 999 an 99999 are: 1634 8208 9474 54748 92727 93084</samp></pre>
<hr>
<div class="page-short-description">

<hr>
<h2>C Program to find area and circumference of circle</h2>

<p>In this program we have to calculate the area and circumference of the circle.
 We have following 2 formulas for finding circumference and area of circle.</p>

<pre>
<code>#include &lt;stdio.h&gt;
 
int main() {
 
   int rad;
   float PI = 3.14, area, ci;
 
   printf("\nEnter radius of circle: ");
   scanf("%d", &rad);
 
   area = PI * rad * rad;
   printf("\nArea of circle : %f ", area);
 
   ci = 2 * PI * rad;
   printf("\nCircumference : %f ", ci);
 
   return (0);
}
</code>
</pre>
<pre>
<h2>Output </h2>
1
2
3	
Enter radius of a circle : 1
Area of circle : 3.14
Circumference  : 6.28
</pre>
				<hr>
				<h2>  C Program Math Function </h2>
				<p>C Programming allows us to perform mathematical operations through the functions defined in <math.h> header file. 
				The <math.h> header file contains various methods for performing mathematical operations such as sqrt(), pow(), ceil(), floor() etc.	
Let's see a simple example of math functions found in math.h header file.</p>
<pre>
<code> #include &lt;stdio.h&gt;
	#include &lt;conio.h&gt; 
	#include &lt;math.h&gt;  
	void main(){  
	clrscr();  
	printf("\n%f",ceil(3.6));  
	printf("\n%f",ceil(3.3));  
	printf("\n%f",floor(3.6));  
	printf("\n%f",floor(3.2));  
	printf("\n%f",sqrt(16));  
	printf("\n%f",sqrt(7));  
	printf("\n%f",pow(2,4));  
	printf("\n%f",pow(3,3));  
	printf("\n%d",abs(-12));  
	getch();  
	}  
</code>
</pre>
	<pre>
	<h2>Output </h2>
4.000000	
4.000000
3.000000
3.000000
4.000000
2.645751
16.000000
27.000000
12
</pre>
<hr>
<h2>C Program Armstrong Number </h2>
<p>Before going to write the c program to check whether the number is Armstrong or not, let's understand what is Armstrong number.
Armstrong number is a number that is equal to the sum of cubes of its digits. For example 0, 1, 153, 370, 371 and 407 are the Armstrong numbers.
Let's try to understand why 153 is an Armstrong number.</p>
	<pre>153 = (1*1*1)+(5*5*5)+(3*3*3)  
   where:  
	(1*1*1)=1  
	(5*5*5)=125  
	(3*3*3)=27  
	So:  
	1+125+27=153  </pre>
Let's try to understand why 371 is an Armstrong number.
	<pre>371 = (3*3*3)+(7*7*7)+(1*1*1)  
	where:  
	(3*3*3)=27  
        (7*7*7)=343  
	(1*1*1)=1  
	So:  
	27+343+1=371</pre>  
Let's see the c program to check Armstrong Number in C.
	<pre>
	<code>#include  &lt;stdio.h&gt; 
	#include &lt;conio.h&gt;
	main()  
	{  
	int n,r,sum=0,temp;  
	clrscr();  
	printf("enter the number=");  
	scanf("%d",&n);  
	temp=n;  
	while(n>0)  
       {  
	r=n%10;  
	sum=sum+(r*r*r);  
	n=n/10;  
	}  
	if(temp==sum)  
	printf("armstrong  number ");  
	else  
	printf("not armstrong number");  
	getch();  
	}  
	</code></pre>
	
<h2>Output</h2>
<pre>
enter the number=153
armstrong number
enter the number=5
not armstrong number</pre>
<hr>
<h2> C Program Palindrome program</h2>
<p>Palindrome number in c: A palindrome number is a number that is same after reverse.
 For example 121, 34543, 343, 131, 48984 are the palindrome numbers.<p>
Palindrome number algorithm
<ul class="list">
<li><p>	Get the number from user</li></p>
<li><p>Hold the number in temporary variable</li></p>
<li><p>Reverse the number</li></p>
<li><p>Compare the temporary number with reversed number</li></p>
<li><p>If both numbers are same, print palindrome number</li></p>
<li><p>Else print not palindrome number</li></p>
</ul>
Let's see the palindrome program in C. In this c program, we will get an input from the user and check whether number is palindrome or not.
	<pre>
	<code>
	#include &lt;stdio.h&gt;  
	#include &lt;conio.h&gt;  
	main()  
	{  
	int n,r,sum=0,temp;  
	clrscr();  
	printf("enter the number=");  
	scanf("%d",&n);  
	temp=n;  
	while(n>0)  
	{  
	r=n%10;  
	sum=(sum*10)+r;  
	n=n/10;  
	}  
	if(temp==sum)  
	printf("palindrome number ");  
	else  
	printf("not palindrome");  	
        getch();  
	}  </code>
	</pre>
<h2>Output</h2>
<pre>
enter the number=151
palindrome  number
enter the number=5621
not palindrome  number</pre>
<hr>
<h2>Assembly program</h2>
<p>We can write assembly program code inside c language program. In such case, all the assembly code must be placed inside asm{} block.</p>
Let's see a simple assembly program code to add two numbers in c program.
<pre> 
<code>#include &lt;stdio.h&gt; 
void main()
 {  
   int a = 10, b = 20, c;  
   asm 
   {  
      mov ax,a  
      mov bx,b  
      add ax,bx  
      mov c,ax  
   }  
   
   printf("c= %d",c);  
 }  
</code>
</pre>

<h2>Output</h2>
c= 30
               <hr>
			   <h2> C Program Factorial </h2>
<p>Factorial Program in C: Factorial of n is the product of all positive descending integers. Factorial of n is denoted by n!.</p> For example:
1.	5! = 5*4*3*2*1 = 120  <br>
2.	3! = 3*2*1 = 6  
<p>Here, 5! is pronounced as "5 factorial", it is also called "5 bang" or "5 shriek".
The factorial is normally used in Combinations and Permutations (mathematics).
There are many ways to write the factorial program in c language. </p>
Let's see the 2 ways to write the factorial program.
<ul class="list">
<li><p>Factorial Program using loop</p></li>
<li><p>Factorial Program using recursion</p></li>
<h3>Factorial Program using loop</h3>
Let's see the factorial Program using loop.
<pre>
<code>
#include &lt;stdio.h&gt;  
#include &lt;conio.h&gt;  
void main(){  
  int i,fact=1,number;  
  clrscr();  
  printf("Enter a number: ");  
  scanf("%d",&number);  
  
  for(i=1;i<=number;i++){  
      fact=fact*i;  
  }  
  printf("Factorial of %d is: %d",number,fact);  
  getch();  
}  </code>
</pre>
<h2>Output</h2>
<pre>
Enter a number: 5
Factorial of 5 is: 120
</pre>

<h3>Factorial Program using recursion in C</h3>
Let's see the factorial program in c using recursion.

  <pre>
<code>
#include &lt;stdio.h&gt;  
#include &lt;conio.h&gt;
long factorial(int n)  
{  
  if (n == 0)  
    return 1;  
  else  
    return(n * factorial(n-1));  
}  
   
void main()  
{  
  int number;  
  long fact;  
  clrscr();  
  printf("Enter a number: ");  
  scanf("%d", &number);   
   
  fact = factorial(number);  
  printf("Factorial of %d is %ld\n", number, fact);  
  getch();  
}  
</code>
</pre>

<h2>Output</h2>
<pre>
Enter a number: 6
Factorial of 5 is: 720
	</pre>

</div>
			  <hr>
				</div>
				<?php include "sidebar_right.php" ?>
    
    </div>
    </div>
<?php include "foot.php" ?>