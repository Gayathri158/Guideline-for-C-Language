 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="alphabet.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="removechar.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div>
               <hr>
<h1>Largest number among three numbers</h1>
In this example, the largest number among three numbers (entered by the user) is found using three different methods.
<p>This program uses only if statement to find the largest number.</p>


<h3> Example 1</h3>

<pre>
<code>#include &lt;stdio.h&gt;
int main()
{
    double n1, n2, n3;

    printf(&quot;Enter three different numbers: &quot;);
    scanf(&quot;%lf %lf %lf&quot;, &amp;n1, &amp;n2, &amp;n3);

    if( n1&gt;=n2 &amp;&amp; n1&gt;=n3 )
        printf(&quot;%.2f is the largest number.&quot;, n1);

    if( n2&gt;=n1 &amp;&amp; n2&gt;=n3 )
        printf(&quot;%.2f is the largest number.&quot;, n2);

    if( n3&gt;=n1 &amp;&amp; n3&gt;=n2 )
        printf(&quot;%.2f is the largest number.&quot;, n3);

    return 0;
}</code></pre>
<h3>Example 2</h3>

<pre>
<code>#include &lt;stdio.h&gt;
int main()
{
    double n1, n2, n3;

    printf(&quot;Enter three numbers: &quot;);
    scanf(&quot;%lf %lf %lf&quot;, &amp;n1, &amp;n2, &amp;n3);

    if (n1&gt;=n2)
    {
        if(n1&gt;=n3)
            printf(&quot;%.2lf is the largest number.&quot;, n1);
        else
            printf(&quot;%.2lf is the largest number.&quot;, n3);
    }
    else
    {
        if(n2&gt;=n3)
            printf(&quot;%.2lf is the largest number.&quot;, n2);
        else
            printf(&quot;%.2lf is the largest number.&quot;,n3);
    }
    
    return 0;
}
</code></pre>
<h3>Example 3</h3>

<pre>
<code>#include &lt;stdio.h&gt;
int main()
{
    double n1, n2, n3;

    printf(&quot;Enter three numbers: &quot;);
    scanf(&quot;%lf %lf %lf&quot;, &amp;n1, &amp;n2, &amp;n3);

    if( n1&gt;=n2 &amp;&amp; n1&gt;=n3)
        printf(&quot;%.2lf is the largest number.&quot;, n1);

    else if (n2&gt;=n1 &amp;&amp; n2&gt;=n3)
        printf(&quot;%.2lf is the largest number.&quot;, n2);

    else
        printf(&quot;%.2lf is the largest number.&quot;, n3);

    return 0;
}
</code></pre>

<p>Though, the largest number among three numbers is found using multiple ways, the output of all these program will be same.</p>

<pre>
<samp>Enter three numbers: -4.5
3.9
5.6
5.60 is the largest number.
</samp></pre>

	<hr />
<div class="pre-btn">
<a href="alphabet.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="removechar.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				</div>
				<?php include "sidebar_right.php" ?>
    
    </div>
    </div>

<?php include "foot.php" ?>