 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="large.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="example.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div>
               
<hr>
<div class="page-short-description">
<h1>Remove Characters in String Except Alphabets</h1>

This program takes a strings from user and removes all characters in that string except alphabets.</div>

<pre>
<code>#include&lt;stdio.h&gt;

int main()
{
    char line[150];
    int i, j;
    printf(&quot;Enter a string: &quot;);
    gets(line);

    for(i = 0; line[i] != &#39;\0&#39;; ++i)
    {
        while (!( (line[i] &gt;= &#39;a&#39; &amp;&amp; line[i] &lt;= &#39;z&#39;) || (line[i] 
		&gt;= &#39;A&#39; &amp;&amp; line[i] &lt;= &#39;Z&#39;) || line[i] == &#39;\0&#39;) )
        {
            for(j = i; line[j] != &#39;\0&#39;; ++j)
            {
                line[j] = line[j+1];
            }
            line[j] = &#39;\0&#39;;
        }
    }
    printf(&quot;Output String: &quot;);
    puts(line);
    return 0;
}
</code></pre>
<p><strong>Output</strong></p>
<pre>
Enter a string: p2&#39;r-o@gram84iz./
Output String: programiz</pre>
<p>This program takes a string from the user and stored in the variable <var>line</var>.</p>
<p>The, within the for loop, each character in the string is checked if it&#39;s an alphabet or not.</p>
<p>If any character inside a string is not a alphabet, all characters after it including the null character is shifted by 1 position to the left.</p>
<hr />
<div class="pre-btn">
<a href="large.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="example.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				
    </div>
	<?php include "sidebar_right.php" ?>
    </div>
    </div>

<?php include "foot.php" ?>