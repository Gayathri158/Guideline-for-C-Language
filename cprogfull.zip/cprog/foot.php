

<div class="footer-copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-1">
                <a href="home.php" class="logo"> <img alt="C Programming"
                                          class="img-responsive"
                                         src="assets/img/images.jpg">
                </a>
            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
                <nav id="sub-menu">
                    <ul>
                        <li><a href="home.php">Home</a></li>
						<li><a href="contact.php">Contact</a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
               <!--  <p>© Copyright 2017. All Rights Reserved.</p> --> 
			   <p> " C is quirky, flawed, and an enormous success.!!! " - Dennis M. Ritchie</p>
            </div>
           <!-- <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="news-group">
                    <input type="text" class="form-control-foot search" name="textemail" id="textemail"
                           autocomplete="off" placeholder="Enter email for newsletter">
                    <span class="input-group-btn"> <button class="btn btn-default btn-footer" id="btnemail"
                                                           type="submit" onclick="javascript:void(0);">go</button> </span>
                    <div id="newsresponse"></div>
                </div>
            </div> -->
        </div>
    </div>
</div>
</div>
<!-- Libs -->

</body>
</html>