 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="third.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="conv.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div><hr>
<h1>Break statement</h1>
<p>The break statement in C language is used to break the execution of loop (while, do while and for) and switch case.
In case of inner loops, it terminates the control of inner loop only.</p>
There can be two usage of C break keyword:
1.	With switch case <br>
2.	With loop
<h3>Syntax</h3>
<pre>jump-statement;  
break;</pre>  
The jump statement in c break syntax can be while loop, do while loop, for loop or switch case.

<h3>Example of C break statement with switch case</h3>
Click here to see the example of C break with switch statement.
Example of C break statement with loop
<pre>
<code>
#include &lt;stdio.h&gt;    
#include &lt;conio.h&gt;    
void main(){    
int i=1;//initializing a local variable  
clrscr();    
  
//starting a loop from 1 to 10  
for(i=1;i<=10;i++){    
printf("%d \n",i);  
if(i==5){//if value of i is equal to 5, it will break the loop  
break;  
}  
}//end of for loop  
  
getch();    
}</code>
</pre>    
<h3>Output</h3>
<pre>
1
2
3
4
5</pre>
As you can see on console output, loop from 1 to 10 is not printed after i==5.

<h3>C break statement with inner loop</h3>
In such case, it breaks only inner loop, but not outer loop.
<pre>
<code>
#include &lt;stdio.h&gt;    
#include &lt;conio.h&gt;    
void main(){    
int i=1,j=1;//initializing a local variable  
clrscr();    
  
for(i=1;i<=3;i++){    
for(j=1;j<=3;j++){  
printf("%d &d\n",i,j);  
if(i==2 && j==2){  
break;//will break loop of j only  
}  
}  
}//end of for loop  
  
getch();    
}    
</code>
</pre>
<h3>Output</h3>
<pre>	
1 1
1 2
1 3
2 1
2 2
3 1
3 2
3 3
</pre>
As you can see the output on console, 2 3 is not printed because there is break
statement after printing i==2 and j==2. But 3 1, 3 2 and 3 3 is printed because break statement works for inner loop only.

<h2>C continue statement</h2>
<p>The continue statement in C language is used to continue the execution of loop (while, do while and for).
 It is used with if condition within the loop.</p>
In case of inner loops, it continues the control of inner loop only.
<h3>Syntax</h3>
	jump-statement;  
	continue;  
The jump statement can be while, do while and for loop.
<h3>
Example of continue statement in c</h3>

<pre>
<code>
#include &lt;stdio.h&gt;    
#include &lt;conio.h&gt;    
void main(){    
int i=1;//initializing a local variable  
clrscr();    
  
//starting a loop from 1 to 10  
for(i=1;i<=10;i++){    
if(i==5){//if value of i is equal to 5, it will continue the loop  
continue;  
}  
printf("%d \n",i);  
}//end of for loop  
  
getch();    
}    
</code>
</pre>

<h3>Output</h3>
<pre>
1
2
3
4
6
7
8
9
10</pre>
As you can see, 5 is not printed on the console because loop is continued at i==5.

<h3>C continue statement with inner loop</h3>
In such case, C continue statement continues only inner loop, but not outer loop.
<pre>
<code>
#include &lt;stdio.h&gt;    
#include &lt;conio.h&gt;    void main(){    
int i=1,j=1;//initializing a local variable  
clrscr();    
  
for(i=1;i<=3;i++){    
for(j=1;j<=3;j++){  
if(i==2 && j==2){  
continue;//will continue loop of j only  
}  
printf("%d &d\n",i,j);  
}  
}//end of for loop  
  
getch();    
}    
</code>
</pre>
<h3>Output</h3>
<pre>
1 1	
1 2
1 3
2 1
2 3
3 1
3 2
3 3
As you can see, 2 2 is not printed on the console because inner loop
is continued at i==2 and j==2.
</pre>

<h2>C goto statement</h2>
<p>The goto statement is known as jump statement in C language. 
It is used to unconditionally jump to other label.It transfers control
to otherparts of the program.It is rarely used today 
because it makes program less readable and complex.</p>
Let's see a simple example to use goto statement in C language.
<pre>
<code>
#include &lt;stdio.h&gt;
#include &lt;conio.h&gt;
void main() {  
  int age;  
  clrscr();  
   ineligible:  
   printf("You are not eligible to vote!\n");  
  
   printf("Enter you age:\n");  
   scanf("%d", &age);  
   if(age<18)  
        goto ineligible;  
   else  
        printf("You are eligible to vote!\n");  
  
   getch();  
}  
</code>
</pre>

<h3>Output:</h3>
<pre>
You are not eligible to vote!
Enter you age:
11
You are not eligible to vote!
Enter you age:
44
You are eligible to vote!

		</pre>		
			
				<hr />
<div class="pre-btn">
<a href="third.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="conv.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				
    </div>
	<?php include "sidebar_right.php" ?>
    </div>
    </div>

<?php include "foot.php" ?>