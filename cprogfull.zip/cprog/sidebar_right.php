<div class="row">
    <div class="col-md-3" id="rightbar">
		<li class="heading">Newsletter Subscription..!</li>
		<br/>
		<input type="text" name="email" id="subscribe_txt" placeholder="Type Email-ID.." maxlength="30" class="form-control what">
		
		<button id="subscribe" class="btn btn-primary pull-right">Subscribe</button>
		<br/>
								<li class="heading">Video Session!</li>
								
								<br/>
                            <a href="https://www.youtube.com/watch?v=aUrQIxWz4bk" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Tamil Video 1
                            </a>
								<br/>
								<br/>
								 <a href="https://www.youtube.com/watch?v=PIHxNIKUc40" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Tamil Video 2
                            </a>
								<br/>
								<br/>
							
                            <a href="https://www.youtube.com/watch?v=-CpG3oATGIs" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in English Video 1
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=N349SLNdTwg" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in English Video 2
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=gojQgp6fhvQ" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Hindi Video 1
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=ZFiFX3IGuFA" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Hindi Video 2
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=O81IgSTdWXU" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Kannada Video 1
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=ZVijjhEkyrc" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Kannada Video 2
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=EPGSPkAWXzE" target="_blank"  style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Telugu Video 1
                            </a>
							<br/>
							<br/>
							
							 <a href="https://www.youtube.com/watch?v=PAvjNxfYiZc" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Telugu Video 2
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=IGD1WwWTJlk" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Malayalam Video 1
                            </a>
							<br/>
							<br/>
							 <a href="https://www.youtube.com/watch?v=1ZV0FA57_-I" target="_blank" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                          
						    Knowledge of C programming in Malayalam Video 2
                            </a>
    </div>
			</div>
