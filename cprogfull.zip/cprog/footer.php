</div>
</div>

<div class="footer-copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-1">
                <a href="https://www.tutorialspoint.com/index.htm" class="logo"> <img alt="Tutorials Point"
                                                                                      class="img-responsive"
                                                                                      src="assets/img/logo-footer.png">
                </a>
            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
                <nav id="sub-menu">
                    <ul>
                        <li><a href="https://www.tutorialspoint.com/about/tutorials_writing.htm">Write for us</a>
                        </li>
                        <li><a href="https://www.tutorialspoint.com/about/faq.htm">FAQ's</a></li>
                        <li><a href="https://www.tutorialspoint.com/about/about_helping.htm">Helping</a></li>
                        <li><a href="https://www.tutorialspoint.com/about/contact_us.htm">Contact</a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <p>© Copyright 2017. All Rights Reserved.</p>
            </div>
        <!--    <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="news-group">
                    <input type="text" class="form-control-foot search" name="textemail" id="textemail"
                           autocomplete="off" placeholder="Enter email for newsletter">
                    <span class="input-group-btn"> <button class="btn btn-default btn-footer" id="btnemail"
                                                           type="submit" onclick="javascript:void(0);">go</button> </span>
                    <div id="newsresponse"></div>
                </div>
            </div> -->
        </div>
    </div>
</div>
</div>
<!-- Libs -->

</body>
</html>