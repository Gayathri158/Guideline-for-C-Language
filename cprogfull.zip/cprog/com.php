 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="cmd.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="more.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>
                <div class="clearer"></div>
				<hr>
               <h1>The C Compiler</h1>
<p>The source code written in source file is the human readable source for your program. It needs to be "compiled", into machine language so that your CPU can actually execute the program as per the instructions given.</p>
<p>The compiler compiles the source codes into final executable programs. The most frequently used and free available compiler is the GNU C/C++ compiler, otherwise you can have compilers either from HP or Solaris if you have the respective operating systems.</p>
<p>The following section explains how to install GNU C/C++ compiler on various OS. We keep mentioning C/C++ together because GNU gcc compiler works for both C and C++ programming languages.</p>
<h2>Installation on UNIX/Linux</h2>
<p>If you are using <b>Linux or UNIX</b>, then check whether GCC is installed on your system by entering the following command from the command line &minus;</p>
<pre class="result notranslate">
$ gcc -v
</pre>
<p>If you have GNU compiler installed on your machine, then it should print a message as follows &minus;</p>
<pre class="result notranslate">
Using built-in specs.
Target: i386-redhat-linux
Configured with: ../configure --prefix=/usr .......
Thread model: posix
gcc version 4.1.2 20080704 (Red Hat 4.1.2-46)
</pre>
<p>If GCC is not installed, then you will have to install it yourself using the detailed instructions available at <a href="http://gcc.gnu.org/install/" rel="nofollow" target="_blank">http://gcc.gnu.org/install/</a></p>
<p>This tutorial has been written based on Linux and all the given examples have been compiled on the Cent OS flavor of the Linux system.</p>
<h2>Installation on Mac OS</h2>
<p>If you use Mac OS X, the easiest way to obtain GCC is to download the Xcode development environment from Apple's web site and follow the simple installation instructions. Once you have Xcode setup, you will be able to use GNU compiler for C/C++.</p>
<p>Xcode is currently available at <a href="http://developer.apple.com/technologies/tools/" rel="nofollow" target="_blank">developer.apple.com/technologies/tools/</a>.</p>
<h2>Installation on Windows</h2>
<p>To install GCC on Windows, you need to install MinGW. To install MinGW, go to the MinGW homepage, <a href="http://www.mingw.org" rel="nofollow" target="_blank"> www.mingw.org</a>, and follow the link to the MinGW download page. Download the latest version of the MinGW installation program, which should be named MinGW-&lt;version&gt;.exe.</p>
<p>While installing Min GW, at a minimum, you must install gcc-core, gcc-g++, binutils, and the MinGW runtime, but you may wish to install more.</p>
<p>Add the bin subdirectory of your MinGW installation to your <b>PATH</b> environment variable, so that you can specify these tools on the command line by their simple names.</p>
<p>After the installation is complete, you will be able to run gcc, g++, ar, ranlib, dlltool, and several other GNU tools from the Windows command line.</p>
				
				<hr />
<div class="pre-btn">
<a href="cmd.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
				<div class="nxt-btn">
       <a href="more.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				</div>
<?php include "sidebar_right.php" ?>
        </div>
    </div>

<?php include "foot.php" ?>