<?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">
                <div class="clearer"></div>
               <hr>
<h1>Contact Learn C</h1>
<!-- Page Scripts -->
<hr class="tall">
<ul class="contact">
<li><p><i class="icon icon-dribbble"></i> <strong>E-mail ID </strong>-learncprogramming123@gmail.com <!--<a href="learncprogramming123@gmail.com"></a>--></p></li>
</ul>
<hr class="tall">
<form action="tp-contact.php" name="MainForm" method="post" target="_self">
<div class="job-box">
<div class="row">
<div class="col-md-12">
<label>Your Name</label>
<input type="text" name="contactp" id="contactp" maxlength="30" class="form-control what"/>
</div>
</div>
<div class="row">
<div class="col-md-12">
<label>Your Email <i>(required)</i></label>
<input type="text" name="emailid" id="emailid" maxlength="75" class="form-control what"/>
</div>
</div>
<div class="row">
<div class="col-md-12">
<label>Subject :</label>
<input type="text" name="subject" id="subject" maxlength="50" class="form-control what"/>
</div>
</div>
<div class="row">
<div class="col-md-12">
<label>Message <i>(required)</i></label>
<textarea id="Message" name="message" class="form-control what"></textarea>
</div>
</div>
<br />
<div class="row">
<div class="col-md-12">
<div class="g-recaptcha" data-sitekey="6LdN1Q8UAAAAAL2hooUYE9Rl-s1nrW9aFN35N5dv"></div>
</div>
</div>

<div class="row">
<div class="col-md-12">
<input type="submit" name="submit" value="Post it" class="submit"  style="top:5px; left:12px;" onclick="return ValidatePost();"
<!--<a href="learncprogramming123@gmail.com"></a>--> 
</div>
</div> 

</div>
</form>

                <hr>
				<?php include "sidebar_right.php" ?>
    </div>
    </div>
    </div>

<?php include "foot.php" ?>