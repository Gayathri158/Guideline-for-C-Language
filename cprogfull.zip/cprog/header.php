<!DOCTYPE html>
<!-- saved from url=(0053)https://www.tutorialspoint.com/cprogramming/index.htm -->
<html style="" class=" js no-touch csstransforms3d csstransitions"><!--<![endif]-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Basic -->

    <title>Learn C </title>

    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes">
    <meta name="robots" content="index, follow">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <script type="text/javascript" src="assets/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="assets/plugins/search/search.js"></script>
    <script type="text/javascript" src="sweetalert.min.js"></script>
    <link rel="stylesheet" href="assets/css/style-min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="assets/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="sweetalert.css">
<script type="text/javascript">
	$(document).ready(function () {
		//Disable cut copy paste
		
		//Disable mouse right click
		function returnFalse(e) {        
        return false;
}
$(document).bind("contextmenu", returnFalse); // disable contextmenu

$(document).bind("cut", returnFalse);
$(document).bind("copy", returnFalse);
$(document).bind("paste", returnFalse);

		
		$("#search").jsearch({
			rowClass     : '.lii',
			fieldClass   : '.search',
			minLength    : 1,
			triggers     : 'keyup',
			caseSensitive: false
		});
		
		$("#subscribe").on("click",function(){
			var sub = $("#subscribe_txt").val();
			var email = {};
			email.email = sub;
			if(sub !==""){
				//alert(sub)
				$.ajax({
					url:"check.php",
					data:email,
					type:"POST",
					success:function(a){						
											   
						//Disable mouse right click
						$(document).unbind("contextmenu", returnFalse); // enable contextmenu
						$(document).unbind("cut", returnFalse);
						$(document).unbind("copy", returnFalse);
						$(document).unbind("paste", returnFalse);
						alert(a);
						var t =  "Now you are Copy and Pasting Our C Programming Content";
						
						swal("Success",t)

					}
				})
			}else{
				alert("Enter Mail id..")
			}
		});
	});
	</script>
</head>
<?php 
$directoryURI = $_SERVER['REQUEST_URI'];
$path = parse_url($directoryURI, PHP_URL_PATH);
$components = explode('/', $path);
$first_part = $components[2];
//print_r($first_part);
?>
<body>
<header>

	<div class="container">
	<div class="row">
            <div class="col-md-1">
            <a href="home.php" class="logo" title="Learn C"><img alt="C Programming"
											class="img-responsive" 
											src="assets/img/images.jpg" >
            </a>
       </div>
	   <div class="col-md-11">
			<h1><center> Learn C Programming </center></h1>
	   </div>
	   </div>
	   </div>
	   
        <!-- search code here  -->
        <button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse"
                id="pull" style="top: 24px!important"><i class="icon icon-bars"></i></button>
    </div>

    <div class="navbar nav-main">
        <div class="container">
            <nav class="nav-main mega-menu">
                <ul class="nav nav-pills nav-main" id="mainMenu">
                    <li class="dropdown no-sub-menu"><a class="dropdown"
                                                        href="home.php"><i
                                    class="icon icon-home"></i> Home</a></li>
					<li class="dropdown no-sub-menu"><a class="dropdown"
                                                        href="example.php"><i
                                    class="icon icon-search"></i> Examples</a></li>
                    <li class="dropdown no-sub-menu"><a class="dropdown"
                                                        href="contact.php"><i
                                    class="fa-user"> </i> Contact</a></li>
		       		<li class="dropdown no-sub-menu"><a class="dropdown"
                                                        href="thankyou.php"><i
                                    class="fa fa-sign-out"></i> Logout</a></li>
                    </ul>
            </nav>
            <div class="submenu-item sub-main-menu" id="top-sub-menu"></div>

        </div>
    </div>
</header>
<div style="clear:both;"></div>
<div role="main" class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <aside class="sidebar">
                    <div class="mini-logo">
                        <!-- <img src="./C Tutorial_files/c-mini-logo.jpg" alt=--> "C Programming" 
                    </div>
                    <ul class="nav nav-list primary left-menu">
                        <li class="heading">Learn C Programming</li>
						<input type="text" name="search" id="search" placeholder="Search.." maxlength="30" class="form-control what"/>
                        <li class="lii">
                            <a href="home.php" class="search"
                               style="<?php if ($first_part=="home.php") {echo "background: bisque;"; } else  {echo "noactive";}?>"
							   >
                                 Home
                            </a>
                        </li>
						
                        <li class="lii">
                            <a href="overview.php" class="search" style="<?php if ($first_part=="overview.php") {echo "background: bisque;"; } else  {echo "noactive";}?>"
							>
                                 Overview
                            </a>
                        </li>
						
						<li class="lii">
                            <a class="search" href="ev.php" style="<?php if ($first_part=="ev.php") {echo "background: bisque;"; } else  {echo "noactive";}?>" >
                                Local Environment Setup
                            </a>
                        </li>
<li class="lii">
                            <a class="search" href="pgmstu.php" style="<?php if ($first_part=="pgmstu.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Program Stucture
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="bassyn.php" style="<?php if ($first_part=="bassyn.php") {echo "background: bisque;"; } else  {echo "noactive";}?>" >
                                Basic Syntax
                            </a>
                        </li>
												<li class="lii">
                            <a class="search" href="dt.php" style="<?php if ($first_part=="dt.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Data Type
                            </a>
                        </li>
						 </li>
									<li class="lii">
                            <a class="search" href="vari.php" style="<?php if ($first_part=="vari.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Variable
                            </a>
                        </li>
						 </li>
						 </li>
									<li class="lii">
                            <a class="search" href="cons.php" style="<?php if ($first_part=="cons.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Constants & Literals
                            </a>
                        </li>
							<li class="lii">
                            <a class="search" href="sto.php" style="<?php if ($first_part=="sto.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Storage Class
                            </a>
                        </li>
													<li class="lii">
                            <a class="search" href="oper.php" style="<?php if ($first_part=="oper.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Operator
                            </a>
                        </li>
								<li class="lii">
                            <a class="search" href="des.php" style="<?php if ($first_part=="des.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Decision Making
                            </a>
                        </li>
														<li class="lii">
                            <a class="search" href="loop.php" style="<?php if ($first_part=="loop.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Loops
                            </a>
                        </li>
										<li class="lii">
                            <a class="search" href="func.php" style="<?php if ($first_part=="func.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Functions
                            </a>
                        </li>
																<li class="lii">
                            <a class="search" href="scope.php" style="<?php if ($first_part=="scope.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Scope Rules
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="array.php" style="<?php if ($first_part=="array.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Array
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="pointer.php" style="<?php if ($first_part=="pointer.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Pointers
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="strings.php" style="<?php if ($first_part=="strings.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Strings
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="stuc.php" style="<?php if ($first_part=="stuc.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Structure
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="uni.php" style="<?php if ($first_part=="uni.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Union
                            </a>
                        </li>
												<li class="lii">
                            <a class="search" href="bit.php" style="<?php if ($first_part=="bit.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Bit Fields
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="typ.php" style="<?php if ($first_part=="typ.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Typedef
                            </a>
                        </li>
												<li class="lii">
                            <a class="search" href="inout.php" style="<?php if ($first_part=="inout.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                Input & Output
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="file.php" style="<?php if ($first_part=="file.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                                File I/O
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="pre.php" style="<?php if ($first_part=="pre.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Preprocessor
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="headfile.php" style="<?php if ($first_part=="headfile.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Header File
                            </a>
                        </li>	
												<li class="lii">
                            <a class="search" href="typecase.php" style="<?php if ($first_part=="typecase.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Type Casting
                            </a>
                        </li>	
							<li class="lii">
                            <a class="search" href="error.php" style="<?php if ($first_part=="error.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Error Handling
                            </a>
                        </li>	
													<li class="lii">
                            <a class="search" href="rec.php" style="<?php if ($first_part=="rec.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Recursion
                            </a>
                        </li>	
						<li class="lii">
                            <a class="search" href="aru.php" style="<?php if ($first_part=="aru.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Variable Argument
                            </a>
                        </li>	
						<li class="lii">
                            <a class="search" href="memory.php" style="<?php if ($first_part=="memory.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Memory Management
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="cmd.php" style="<?php if ($first_part=="cmd.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Command Line Arguments
                            </a>
                        </li>	
                            </a>
                        </li>	
							<li class="lii">
                            <a class="search" href="com.php" style="<?php if ($first_part=="com.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Compiler
                            </a>
                        </li>
											<ul class="nav nav-list primary left-menu">
                        <li class="heading">More Topics</li>
						
								<li class="lii">
                            <a class="search" href="more.php" style="<?php if ($first_part=="more.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Keyboard Shortcuts
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="third.php" style="<?php if ($first_part=="third.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                               Third Variable
                            </a>
                        </li>
												<li class="lii">
                            <a class="search" href="bre.php" style="<?php if ($first_part=="bre.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Break Statement
                            </a>
                        </li>
							<li class="lii">
                            <a class="search" href="conv.php" style=" <?php if ($first_part=="conv.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Convert in String
                            </a>
                        </li>
										<li class="lii">
                            <a class="search" href="decbin.php" style="<?php if ($first_part=="decbin.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Convert Decimal to Binary
                            </a>
                        </li>

					<ul class="nav nav-list primary left-menu">
                        <li class="heading">More Examples</li>
						
                        
												<li class="lii">
                            <a class="search" href="table.php" style="<?php if ($first_part=="table.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Print Tables
                            </a>
                        </li>
						 <li class="lii">
						 <a class="search" href="alphabet.php" style="<?php if ($first_part=="alphabet.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Print Alphabet Triangle
                            </a>
                        </li>
						 <li class="lii">
						 <a class="search" href="large.php" style="<?php if ($first_part=="large.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Print Largest Number
                            </a>
                        </li>
						<li class="lii">
						 <a class="search" href="removechar.php" style="<?php if ($first_part=="removechar.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Remove Except String
                            </a>
                        </li>
						<li class="lii">
                            <a class="search" href="example.php" style="<?php if ($first_part=="example.php") {echo "background: bisque;"; } else  {echo "noactive";}?>">
                           
                                Examples
                            </a>
                        </li>
						
                    </ul>
                </aside>
            </div>
