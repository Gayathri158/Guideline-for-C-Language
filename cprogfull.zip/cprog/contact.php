 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">
                <div class="clearer"></div>
               <hr>
<h1>Contact Learn C</h1>
<!-- Page Scripts -->
<hr class="tall">
<ul class="contact">
<li><p><i class="icon icon-dribbble"></i> <strong>E-mail ID </strong>-learncprogramming123@gmail.com <!--<a href="learncprogramming123@gmail.com"></a>--></p></li>
</ul>
<hr class="tall">
<form action="PHPMailer/examples/gmail.php" name="MainForm" method="post" target="_self">
<div class="job-box">
<div class="row">
<div class="col-md-12">
<label>Your Name</label>
<input type="text" name="name" id="contactp" maxlength="30" class="form-control what"/>
</div>
</div>
<div class="row">
<div class="col-md-12">
<label>Your Email <i>(required)</i></label>
<input type="text" name="email" id="emailid" maxlength="75" class="form-control what"/>
</div>
</div>
<div class="row">
<div class="col-md-12">
<label>Subject :</label>
<input type="text" name="subject" id="subject" maxlength="50" class="form-control what"/>
</div>
</div>
<div class="row">
<div class="col-md-12">
<label>Message <i>(required)</i></label>
<textarea id="Message" name="message" class="form-control what"></textarea>
</div>
</div>
<br />
<div class="row">
<div class="col-md-12">
<div class="g-recaptcha" data-sitekey="6LdN1Q8UAAAAAL2hooUYE9Rl-s1nrW9aFN35N5dv"></div>
</div>
</div>

<div class="row">
<div class="col-md-12">
<input type="submit" name="submit" value="Post it" class="submit_data_con"  style="top:5px; left:12px;" onclick="return ValidatePost();">
  <!--<a href="learncprogramming123@gmail.com"></a>--> 
</div>
</div> 

</div>
</form>
<script type="text/javascript">
function ValidatePost()
{
	if( document.MainForm.emailid.value == "")
	{
		alert( "Please enter correct email ID..." )
		document.MainForm.emailid.focus() ;
		return false ;
	}
        if( !validateEmail( document.MainForm.emailid.value )){
		alert( "Please enter correct email ID..." )
		document.MainForm.emailid.focus() ;
		return false ;
        }
	if( document.MainForm.message.value == "" )
	{
		alert( "You missed to enter your message ..." )
		document.MainForm.message.focus() ;
		return false ;
	}
	return true;
}
function validateEmail(email){ 
     var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
     return re.test(email); 
}
</script>

<script type="text/javascript">
	$(document).ready(function () {
		/*$(".submit_data_con").on("click",function(){
			var name = $("#contactp").val();
			var email = $("#emailid").val();
			var subject = $("#subject").val();
			var message = $("#message").val();.
			
			var email = {};
			email.name = name;
			email.email = email;
			email.subject = subject;
			email.message = message;
			if(sub !==""){
				//alert(sub)
				$.ajax({
					url:"PHPMailer/examples/gmail.php",
					data:email,
					type:"POST",
					success:function(a){						
						alert(a)
					}
				})
			}else{
				alert("Enter Mail id..")
			}
		});*/
	});
	</script>


                <hr>
    </div>
				<?php include "sidebar_right.php" ?>
    </div>
    </div>

<?php include "foot.php" ?>