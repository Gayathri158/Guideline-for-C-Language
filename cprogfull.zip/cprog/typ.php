<?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="bit.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
                <div class="nxt-btn">
                    <a href="inout.php">Next Page <i
                                class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
                </div>
                <div class="clearer"></div>
				<hr>
				<h1> Typedef </h1>
<p>You can use <b>typedef</b> to give a name to your user defined data types as well. For example, you can use typedef with structure to define a new data type and then use that data type to define structure variables directly as follows &minus;</p>
<pre class="prettyprint notranslate tryit">
#include &lt;stdio.h&gt;
#include &lt;string.h&gt;
 
typedef struct Books {
   char title[50];
   char author[50];
   char subject[100];
   int book_id;
} Book;
 
int main( ) {

   Book book;
 
   strcpy( book.title, "C Programming");
   strcpy( book.author, "Nuha Ali"); 
   strcpy( book.subject, "C Programming Tutorial");
   book.book_id = 6495407;
 
   printf( "Book title : %s\n", book.title);
   printf( "Book author : %s\n", book.author);
   printf( "Book subject : %s\n", book.subject);
   printf( "Book book_id : %d\n", book.book_id);

   return 0;
}
</pre>
<p>When the above code is compiled and executed, it produces the following result &minus;</p>
<pre class="result notranslate">
Book  title : C Programming
Book  author : Nuha Ali
Book  subject : C Programming Tutorial
Book  book_id : 6495407
</pre>
<h2>typedef vs #define</h2>
<p><b>#define</b> is a C-directive which is also used to define the aliases for various data types similar to <b>typedef</b> but with the following differences &minus;</p>
<ul class="list">
<li><p><b>typedef</b> is limited to giving symbolic names to types only where as <b>#define</b> can be used to define alias for values as well, q., you can define 1 as ONE etc.</p></li>
<li><p><b>typedef</b> interpretation is performed by the compiler whereas <b>#define</b> statements are processed by the pre-processor.</p></li>
</ul>
<p>The following example shows how to use #define in a program &minus;</p>
<pre class="prettyprint notranslate tryit">
#include &lt;stdio.h&gt;
 
#define TRUE  1
#define FALSE 0
 
int main( ) {
   printf( "Value of TRUE : %d\n", TRUE);
   printf( "Value of FALSE : %d\n", FALSE);

   return 0;
}
</pre>
<p>When the above code is compiled and executed, it produces the following result &minus;</p>
<pre class="result notranslate">
Value of TRUE : 1
Value of FALSE : 0
</pre>
				<hr />
<div class="pre-btn">
<a href="bit.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="inout.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>


                <hr>
				    </div>
					<?php include "sidebar_right.php" ?>
    </div>
    </div>

<?php include "foot.php" ?>
