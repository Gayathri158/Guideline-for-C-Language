 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="decbin.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="alphabet.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div>
               <hr>
			   <h1> Print Tables </h1>
			  
<h2>Program to print table for the given number using do while loop</h2>
<pre>
<code>
#include &lt;stdio.h &gt;
#include &lt;conio.h &gt;
void main()
{    
int i=1,number=0;  
clrscr();    
  
printf("Enter a number: ");  
scanf("%d",&number);  
  
do{  
printf("%d \n",(number*i));  
i++;  
}while(i<=10);  
    
getch();    
}   
</code>
</pre>
 
<h3>Output</h3>
<pre>
Enter a number: 5
5
10
15
20
25
30
35
40
45
50
Enter a number: 10
10
20
30
40
50
60
70
80
90
100 
</pre>
<hr>
<h2>Print table for the given number using C for loop</h2>
<pre>
<code>
#include &lt;stdio.h &gt;
#include &lt;conio.h &gt;    
void main(){    
int i=1,number=0;  
clrscr();    
  
printf("Enter a number: ");  
scanf("%d",&number);  
  
for(i=1;i<=10;i++){    
printf("%d \n",(number*i));  
}  
  
getch();    
}   
</code>
</pre>
 
<h3>Output	</h3>
<pre>
Enter a number: 2
2
4
6
8
10
12
14
16
18
20
Enter a number: 1000
1000
2000
3000
4000
5000
6000
7000
8000
9000
10000
</pre>
<hr>
<h2>Program to print table for the given number using while loop in C</h2>
<pre>
<code>
#include &lt;stdio.h &gt;
#include &lt;conio.h &gt;    
void main(){    
int i=1,number=0;  
clrscr();    
  
printf("Enter a number: ");  
scanf("%d",&number);  
  
while(i<=10){  
printf("%d \n",(number*i));  
i++;  
}  
  
getch();    
}  
 </code>
</pre>
<h3>Output</h3>
<pre>
Enter a number: 50
50
100
150
200
250
300
350
400
450
500
Enter a number: 100
100
200
300
400
500
600
700
800
900
1000
</pre>


				<hr />
<div class="pre-btn">
<a href="decbin.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="alphabet.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				    </div>
					<?php include "sidebar_right.php" ?>
    </div>
    </div>

<?php include "foot.php" ?>

