<?php

$conn = mysqli_connect('localhost', 'root', '', 'cprog') or die("Error connecting database : ".mysqli_connect_error());

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }else{
	  echo "Connection Success";
  }
?>