 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="conv.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="table.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div>
				<br>
<h1>Convert Decimal to Binary</h1>

<p>Decimal to binary in C: We can convert any decimal number (base-10 (0 to 9)) 
into binary number(base-2 (0 or 1)) by c program.</p>
<b>Decimal Number</b>
<p>Decimal naumber is a base 10 number because it ranges from 0 to 9, there are 
total 10 digits between 0 to 9. Any combination of digits is decimal number such as
23, 445, 132, 0, 2 etc.</p>
<b>Binary Number</b>
<p>Binary number is a base 2 number because it is either 0 or 1. Any combination
 of 0 and 1 is binary number such as 1001, 101, 11111, 101010 etc.</p>
Decimal to Binary Conversion Algorithm
<ul class ="list">
<li><P>Step 1: Divide the number by 2 through % (modulus operator) and store the remainder in array></p></li>
<li><P>Step 2: Divide the number by 2 through / (division operator)</p></li>
<li><P>Step 3: Repeat the step 2 until number is greater than 0</p></li>
</ul>
Let's see the c example to convert decimal to binary.
<pre>
<code>
#include &lt;stdio.h&gt;
#include &lt;conio.h&gt;
main()  
{  
int a[10],n,i;  
clrscr();  
printf("Enter the number to convert: ");  
scanf("%d",&n);  
for(i=0;n>0;i++)  
{  
a[i]=n%2;  
n=n/2;  
}  
printf("\nBinary of Given Number is=");  
for(i=i-1;i>=0;i--)  
{  
printf("%d",a[i]);  
}  
getch();  
}  </code>
</pre>
<h3>Output</h3>
<pre>
Enter the number to convert: 5
Binary of Given Number is=101 
</pre>
				<hr />
<div class="pre-btn">
<a href="conv.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="table.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				    </div>
					<?php include "sidebar_right.php" ?>
    </div>
    </div>

<?php include "foot.php" ?>