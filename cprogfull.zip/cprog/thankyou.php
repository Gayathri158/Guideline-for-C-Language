<!DOCTYPE html>
<html lang="en">
<head>
  <title>Thank You</title>
  </head>
  <body background="images (2).jpg" style="background-size:cover">
  <font>
  <center><b><h1> <font color="orange" >Thank You For Visiting Our Web Page </h1></b></center>
  <a href="index.php"><center><i><h2> <font color="skyblue">Login Page </a></h2></i></center>
  </font>
</body>
</html>