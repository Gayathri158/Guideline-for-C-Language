<?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col" style="height: 1851px;">

                <hr>
     
                <div class="nxt-btn">
                    <a href="overview.php">Next Page <i
                                class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
                </div>
                <div class="clearer"></div>
                <hr>

                <h1>Introduction of C language</h1>
                <p>
                    C is a general-purpose, procedural, imperative computer programming language developed in
                    1972 by <b> Dennis M. Ritchie </b> at the Bell Telephone Laboratories to develop the UNIX operating
                    system. C is the most widely used computer language. It keeps fluctuating at number one
                    scale of popularity along with Java programming language, which is also equally popular and
                    most widely used among modern software programmers.
                </p>
				
                <h1>Execute C</h1>
                <p>For most of the examples given in this web page you will find Try it option, so just make use
                    of this option to execute your C programs at the spot and enjoy your learning.</p>
                <p>Try following example using Try it option available at the top right corner of the below
                    sample code box </p>
                <pre class="prettyprint notranslate tryit prettyprinted" style="">
#include &lt;stdio.h &gt;
int main() {
   /* my first program in C */
   printf("Hello, World!");
   return 0;
}
                                </pre>
								Let us analyze the program line by line.
<h3>Line 1: [ #include &lt;stdio.h&gt ]</h3> 
<p>In a C program, all lines that start with # are processed by preprocessor which is a program invoked by the compiler. In a very basic term, preprocessor takes a C program and produces another C program. The produced program has no lines starting with #, all such lines are processed by the preprocessor. In the above example, preprocessor copies the preprocessed code of stdio.h to our file. The .h files are called header files in C. These header files generally contain declaration of functions. We need stdio.h for the function printf() used in the program.
</p>
<h3>Line 2 [ int main() ]</h3> <p>There must to be starting point from where execution of compiled C program begins. In C, the execution typically begins with first line of main(). The void written in brackets indicates that the main doesn’t take any parameter (See this for more details). main() can be written to take parameters also. We will be covering that in future posts.
The int written before main indicates return type of main(). The value returned by main indicates status of program termination. See this post for more details on return type.</p>

<h3>Line 3 and 6: [ { and } ]</h3> <p>In C language, a pair of curly brackets define a scope and mainly used in functions and control statements like if, else, loops. All functions must start and end with curly brackets.<p>

<h3>Line 4 [ printf("Hello, World!"); ]</h3><p> printf() is a standard library function to print something on standard output. The semicolon at the end of printf indicates line termination. In C, semicolon is always used to indicate end of statement.</p>

<h3>Line 5 [ return 0; ]</h3> <p>The return statement returns the value from main(). The returned value may be used by operating system to know termination status of your program. The value 0 typically means successful termination.</p>
                <hr>
                <div class="nxt-btn">
                    <a href="overview.php">Next Page <i
                                class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
                </div>
                <hr>
                <!-- PRINTING ENDS HERE -->

            </div>
        </div>

        <?php include "sidebar_right.php" ?>
    </div>
	

<?php include "foot.php" ?>