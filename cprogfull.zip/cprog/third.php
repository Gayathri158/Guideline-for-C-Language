 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="more.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
								<div class="nxt-btn">
       <a href="bre.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>
<hr>
<h1>To swap two numbers without third variable</h1>

<p>We can swap two numbers without using third variable. There are two common ways to swap two numbers without using third variable</p>
1.	By + and -
2.	By * and /
<h2>Program 1: Using + and - </h2>
Let's see a simple c example to swap two numbers without using third variable.
<pre>
<code>#include &lt;stdio.h&gt;
#include &lt;conio.h&gt;  
main()  
{  
int a=10, b=20;    
clrscr();    
printf("Before swap a=%d b=%d",a,b);    
  
a=a+b;//a=30 (10+20)  
b=a-b;//b=10 (30-20)  
a=a-b;//a=20 (30-10)  
  
printf("\nAfter swap a=%d b=%d",a,b);  
getch();  
}  
</code>
</pre>
<h2>Output</h2>
<pre>Before swap a=10 b=20
After swap a=20 b=10
</pre>

<h2>Program 2: Using * and /</h2>
Let's see another example to swap two numbers using * and /.
	<pre>
	<code>
	#include<stdio.h>  
	#include<conio.h>  
	main()  
	{  
	int a=10, b=20;    
	clrscr();    
    printf("Before swap a=%d b=%d",a,b);    
  
    a=a*b;//a=200 (10*20)  
	b=a/b;//b=10 (200/20)  
	a=a/b;//a=20 (200/10)  
	  
	printf("\nAfter swap a=%d b=%d",a,b);   
	getch();  
	}
</code>
</pre>	
<h2>Output</h2>
<pre>
Before swap a=10 b=20
After swap a=20 b=10
</pre>




                <div class="clearer"></div>
               <hr>
			                   <div class="pre-btn">
                    <a href="more.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>

			   				<div class="nxt-btn">
       <a href="bre.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

			  <hr>
				</div>
				<?php include "sidebar_right.php" ?>
    
    </div>
    </div>
<?php include "foot.php" ?>