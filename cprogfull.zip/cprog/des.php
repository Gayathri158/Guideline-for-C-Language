<?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="oper.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
                <div class="nxt-btn">
                    <a href="loop.php">Next Page <i
                                class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
                </div>
                <div class="clearer"></div>
               

<hr>
<h1> Decision Making</h1>
<p>Decision making structures require that the programmer specifies one or more conditions to be evaluated or tested by the program, along with a statement or statements to be executed if the condition is determined to be true, and optionally, other statements to be executed if the condition is determined to be false.</p>
<p>Show below is the general form of a typical decision making structure found in most of the programming languages &minus;</p>
<img src="/cprogramming/images/decision_making.jpg" alt="Decision making statements in C" />
<p>C programming language assumes any <b>non-zero</b> and <b>non-null</b> values as <b>true</b>, and if it is either <b>zero</b> or <b>null</b>, then it is assumed as <b>false</b> value.</p>
<p>C programming language provides the following types of decision making statements.</p>
<table class="table table-bordered">
<tr>
<th>S.N.</th>
<th style="text-align:center;">Statement &amp; Description</th>
</tr>
<tr>
<td>1</td>
<td><a href="/cprogramming/if_statement_in_c.htm">if statement</a>
<p>An <b>if statement</b> consists of a boolean expression followed by one or more statements.</p></td>
</tr>
<tr>
<td>2</td>
<td><a href="/cprogramming/if_else_statement_in_c.htm">if...else statement</a>
<p>An <b>if statement</b> can be followed by an optional <b>else statement</b>, which executes when the Boolean expression is false.</p></td>
</tr>
<tr>
<td>3</td>
<td><a href="/cprogramming/nested_if_statements_in_c.htm">nested if statements</a>
<p>You can use one <b>if</b> or <b>else if</b> statement inside another <b>if</b> or <b>else if</b> statement(s).</p></td>
</tr>
<tr>
<td>4</td>
<td><a href="/cprogramming/switch_statement_in_c.htm">switch statement</a>
<p>A <b>switch</b> statement allows a variable to be tested for equality against a list of values.</p></td>
</tr>
<tr>
<td>5</td>
<td><a href="/cprogramming/nested_switch_statements_in_c.htm">nested switch statements</a>
<p>You can use one <b>switch</b> statement inside another <b>switch</b> statement(s).</p></td>
</tr>
</table>
<h2>The ? : Operator</h2>
<p>We have covered <b>conditional operator ? :</b> in the previous chapter which can be used to replace <b>if...else</b> statements. It has the following general form &minus;</p>
<pre class="result notranslate">
Exp1 ? Exp2 : Exp3;
</pre>
<p>Where Exp1, Exp2, and Exp3 are expressions. Notice the use and placement of the colon.</p>
<p>The value of a ? expression is determined like this &minus;</p>
<ul class="list">
<li><p>Exp1 is evaluated. If it is true, then Exp2 is evaluated and becomes the value of the entire ? expression.</p></li>
<li><p>If Exp1 is false, then Exp3 is evaluated and its value becomes the value of the expression.</p></li>
</ul>

				<hr />
          <div class="pre-btn">
          <a href="oper.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
          </div>
           <div class="nxt-btn">
        <a href="loop.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
        </div>


                <hr>
				 </div>
				 <?php include "sidebar_right.php" ?>
   
    </div>
    </div>

<?php include "foot.php" ?>