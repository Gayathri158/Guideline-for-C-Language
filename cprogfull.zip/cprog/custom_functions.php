<?php
$conn = mysqli_connect('localhost', 'root', '', 'cprog') or die("Error connecting database : ".mysqli_connect_error());


$post = $_REQUEST;
//    echo "<pre>"; print_r($post); exit;

// >>> Save Company details
if (isset($post['req_from']) && !empty($post['req_from'])) {
    switch ($post['req_from']) {

        // Added for BILL
        case "register":
            //$query = "INSERT INTO users SET units='{$post['unit_name']}', created_at='" . CURRENT_DATE_TIME . "'";
            $query = "INSERT INTO `users`(`username`, `password`, `first_name`, `last_name`, `eamil_id`, `dob`, `age`, `gender`) VALUES ('{$post['uname']}','{$post['password']}','{$post['first_name']}','{$post['last_name']}','{$post['email']}','{$post['dob']}',{$post['age']},'{$post['gender']}')";
			//print_r($query);
            $qry = mysqli_query($conn, $query);			
            print_r($qry);
            exit;
            break;

		case "login":
            //$query = "INSERT INTO users SET units='{$post['unit_name']}', created_at='" . CURRENT_DATE_TIME . "'";
            $query = "SELECT * from users WHERE username='{$post['uname']}' and password='{$post['password']}'";
			//print_r($query);
            $qry = mysqli_query($conn, $query);	
			$get = 	mysqli_fetch_assoc($qry);
			
			//print_r($get);
			if(mysqli_num_rows($qry) > 0){
				print_r(1);
			}else{
				print_r(0);
			}
			
            exit;
            break;

        
    }
}

?>