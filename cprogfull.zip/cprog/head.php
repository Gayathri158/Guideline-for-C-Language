<!DOCTYPE html>
<!-- saved from url=(0053)https://www.tutorialspoint.com/cprogramming/index.htm -->
<html style="" class=" js no-touch csstransforms3d csstransitions"><!--<![endif]-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Basic -->

    <title>Learn C </title>

    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes">
    <meta name="robots" content="index, follow">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <script type="text/javascript" src="assets/js/jquery-1.9.1.min.js"></script>
    <link rel="stylesheet" href="assets/css/style-min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="assets/plugins/font-awesome/css/font-awesome.min.css">
	<script type="text/javascript">
	$(document).ready(function () {
		//Disable cut copy paste
		$('body').bind('cut copy paste', function (e) {
			e.preventDefault();
			//alert(1)
		});
	   
		//Disable mouse right click
		$("body").on("contextmenu",function(e){
			//alert(0)
			return false;
		});
	});
	</script>

</head>
<body>
<header>
    <div class="container">
        <h1 class="logo">
            <a href="https://www.tutorialspoint.com/index.htm" title="Learn C">
                <img alt="C Programming" src="https://www.tutorialspoint.com/green/images/logo.png">
            </a>
        </h1>
		<nav>
            <ul class="nav nav-pills nav-top">
                <li><a href="https://www.tutorialspoint.com/about/about_careers.htm"
                       style="background: #fffb09; font-weight: bold;"><i class="icon icon-suitcase"></i> Jobs</a></li>
                <li><a href="http://www.sendfiles.net/"><i class="fa fa-send"></i> &nbsp;SENDFiles</a></li>
                <li><a href="https://www.tutorialspoint.com/whiteboard.htm"><img
                                src="./C Tutorial_files/image-editor.png" alt="Whiteboard" title="Whiteboard"> &nbsp;Whiteboard</a>
                </li>
                <li><a href="https://www.tutorialspoint.com/netmeeting.php"><i class="fa-camera"></i> &nbsp;Net Meeting</a>
                </li>
                <li><a href="https://www.tutorialspoint.com/online_dev_tools.htm"> <i class="dev-tools-menu"
                                                                                      style="opacity:.5"></i> Tools </a>
                </li>
                <li><a href="https://www.tutorialspoint.com/articles/index.php"><i class="icon icon-file-text-o"></i>
                        &nbsp;Articles</a></li>
            </ul>
        </nav>
        <!-- search code here  -->
        <button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse"
                id="pull" style="top: 24px!important"><i class="icon icon-bars"></i></button>
    </div>

    <div class="navbar nav-main">
        <div class="container">
            <nav class="nav-main mega-menu">
                <ul class="nav nav-pills nav-main" id="mainMenu">
                    <li class="dropdown no-sub-menu"><a class="dropdown"
                                                        href="index.php"><i
                                    class="icon icon-home"></i> Home</a></li>
                    <li class="dropdown no-sub-menu"><a class="dropdown"
                                                        href="cont.php"><i
                                    class="fa-user"> </i> Contact</a></li>
                    </ul>
            </nav>
            <div class="submenu-item sub-main-menu" id="top-sub-menu"></div>

        </div>
    </div>
</header>
<div style="clear:both;"></div>
<div role="main" class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <aside class="sidebar">
                    <div class="mini-logo">
                        <img src="./C Tutorial_files/c-mini-logo.jpg" alt="CProgramming Tutorial">
                    </div>
                    <ul class="nav nav-list primary left-menu">
                        <li class="heading">C Programming Tutorial</li>
						
                        <li>
                            <a href="index.php"
                               style="background-color: rgb(214, 214, 214);">
                                C - Home
                            </a>
                        </li>
						
                        <li>
                            <a href="overview.php">
                                C - Overview
                            </a>
                        </li>
						
						<li>
                            <a href="ev.php">
                               C - Local Environment Setup
                            </a>
                        </li>
<li>
                            <a href="pgmstu.php">
                               C - Program Stucture
                            </a>
                        </li>
						<li>
                            <a href="bassyn.php">
                               C - Basic Syntax
                            </a>
                        </li>
												<li>
                            <a href="dt.php">
                               C - Data Type
                            </a>
                        </li>
						 </li>
												<li>
                            <a href="vari.php">
                               C - Variable
                            </a>
                        </li>
						 </li>
						 </li>
												<li>
                            <a href="cons.php">
                               C - Constants & Literals
                            </a>
                        </li>
							<li>
                            <a href="sto.php">
                               C - Storage Class
                            </a>
                        </li>
													<li>
                            <a href="oper.php">
                               C - Operator
                            </a>
                        </li>
								<li>
                            <a href="des.php">
                               C - Decision Making
                            </a>
                        </li>
														<li>
                            <a href="loop.php">
                               C - Loops
                            </a>
                        </li>
										<li>
                            <a href="func.php">
                               C - Functions
                            </a>
                        </li>
																<li>
                            <a href="scope.php">
                               C - Scope Rules
                            </a>
                        </li>
						
                    </ul>
                </aside>
            </div>
