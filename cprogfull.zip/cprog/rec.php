 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="error.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
           <a href="aru.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
    </div>

                <div class="clearer"></div>
				<hr>
				<h1>Recursion</h1>
<p>Recursion is the process of repeating items in a self-similar way. In programming languages, if a program allows you to call a function inside the same function, then it is called a recursive call of the function.</p>
<pre class="prettyprint notranslate">
void recursion() {
   recursion(); /* function calls itself */
}

int main() {
   recursion();
}
</pre>
<p>The C programming language supports recursion, i.e., a function to call itself. But while using recursion, programmers need to be careful to define an exit condition from the function, otherwise it will go into an infinite loop.</p>
<p>Recursive functions are very useful to solve many mathematical problems, such as calculating the factorial of a number, generating Fibonacci series, etc.</p>
<h2>Number Factorial</h2>
<p>The following example calculates the factorial of a given number using a recursive function &minus;</p>
<pre class="prettyprint notranslate tryit">
#include &lt;stdio.h&gt;

int factorial(unsigned int i) {

   if(i &lt;= 1) {
      return 1;
   }
   return i * factorial(i - 1);
}

int  main() {
   int i = 15;
   printf("Factorial of %d is %d\n", i, factorial(i));
   return 0;
}
</pre>
<p>When the above code is compiled and executed, it produces the following result &minus;</p>
<pre class="result notranslate">
Factorial of 15 is 2004310016
</pre>
<h2>Fibonacci Series</h2>
<p>The following example generates the Fibonacci series for a given number using a recursive function &minus;</p>
<pre class="prettyprint notranslate tryit">
#include &lt;stdio.h&gt;

int fibonacci(int i) {

   if(i == 0) {
      return 0;
   }
	
   if(i == 1) {
      return 1;
   }
   return fibonacci(i-1) + fibonacci(i-2);
}

int  main() {

   int i;
	
   for (i = 0; i &lt; 10; i++) {
      printf("%d\t\n", fibonacci(i));
   }
	
   return 0;
}
</pre>
<p>When the above code is compiled and executed, it produces the following result &minus;</p>
<pre class="result notranslate">
0	
1	
1	
2	
3	
5	
8	
13	
21	
34
</pre>
				<hr />
<div class="pre-btn">
<a href="error.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="aru.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				</div>
				<?php include "sidebar_right.php" ?>
        </div>
    </div>

<?php include "foot.php" ?>