 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="com.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
								<div class="nxt-btn">
       <a href="third.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>
                <div class="clearer"></div>
               
<hr>
<h1>Keyboard <span class="color_h1">Shortcuts</span></h1>
<hr>
<p class="intro">Save time by using keyboard shortcuts.</p>
<hr>

<h2>Keyboard Shortcuts For Windows and Mac</h2>
<p>Keyboard shortcuts are often used in modern operating systems and computer software programs.</p>
<p>Using keyboard shortcuts could save you a lot of time.</p>
<hr>

<h2>Basic Shortcuts</h2>
<table class="w3-table-all notranslate">
<tr>
<th style="width:44%">Description</th>
<th style="width:28%">Windows</th>
<th style="width:28%">Mac OS</th>
</tr>
<tr>
<td>Edit menu</td>
<td>Alt + E</td>
<td>Ctrl + F2 + F</td>
</tr>
<tr>
<td>File menu</td>
<td>Alt + F</td>
<td>Ctrl + F2 + E</td>
</tr>
<tr>
<td>View menu</td>
<td>Alt + V</td>
<td>Ctrl + F2 + V</td>
</tr>     
<tr>
<td>Select all text</td>
<td>Ctrl + A</td>
<td>Cmd + A</td>
</tr>
<tr>
<td>Copy text</td>
<td>Ctrl + C</td>
<td>Cmd + C</td>
</tr>
<tr>
<td>Find text</td>
<td>Ctrl + F</td>
<td>Cmd + F</td>
</tr>  
<tr>
<td>Find and replace text</td>
<td>Ctrl + H</td>
<td>Cmd + F</td>
</tr>     
<tr>
<td>New Document</td>
<td>Ctrl + N</td>
<td>Cmd + N</td>
</tr>
<tr>
<td>Open a file</td>
<td>Ctrl + O</td>
<td>Cmd + O</td>
</tr>
<tr>
<td>Print options</td>
<td>Ctrl + P</td>
<td>Cmd + P</td>
</tr>
<tr>
<td>Save file</td>
<td>Ctrl + S</td>
<td>Cmd + S</td>
</tr>  
<tr>
<td>Paste text</td>
<td>Ctrl + V</td>
<td>Cmd + V</td>
</tr>
<tr>
<td>Cut text</td>
<td>Ctrl + X</td>
<td>Cmd + X</td>
</tr>
<tr>
<td>Redo text</td>
<td>Ctrl + Y</td>
<td>Shift + Cmd + Z </td>
</tr>
<tr>
<td>Undo text</td>
<td>Ctrl + Z</td>
<td>Cmd + Z</td>
</tr>
</table>

<h2>Text Editing</h2>
<table class="w3-table-all notranslate">
<tr>
<th style="width:52%">Description</th>
<th style="width:24%">Windows</th>
<th style="width:24%">Mac OS</th>
</tr>
<tr>
<td style="height:25px"><strong>Cursor Movement</strong></td>
<td style="height:25px"></td>
<td style="height:25px"></td>
</tr>
<tr>
<td>Go to the right or to the beginning of next line break</td>
<td>Right Arrow</td>
<td>Right Arrow</td>
</tr>
<tr>
<td>Go to the left or to the end of previous line break</td>
<td>Left Arrow</td>
<td>Left Arrow</td>
</tr>
<tr>
<td>Go up one row</td>
<td>Up Arrow</td>
<td>Up Arrow</td>
</tr>
<tr>
<td>Go down one row</td>
<td>Down Arrow</td>
<td>Down Arrow</td>
</tr>   
<tr>
<td>Go to the beginning of the current line</td>
<td>Home</td>
<td>Cmd + Left Arrow</td>
</tr>  
<tr>
<td>Go to the end of the current line</td>
<td>End</td>
<td>Cmd + Right Arrow</td>
</tr>   
<tr>
<td>Go to the beginning of the document</td>
<td>Ctrl + Home</td>
<td>Cmd + Up Arrow</td>
</tr>  
<tr>
<td>Go to the end of the document</td>
<td>Ctrl + End</td>
<td>Cmd + Down Arrow</td>
</tr>   
<tr>
<td>Move up one frame</td>
<td>Page Up</td>
<td>Fn + Up Arrow</td>
</tr>
<tr>
<td>Move down one frame</td>
<td>Page Down</td>
<td>Fn + Down Arrow</td>
</tr>   
<tr>
<td>Go to beginning of previous word</td>
<td>Ctrl + Left Arrow</td>
<td>Option + Left Arrow </td>
</tr>
<tr>
<td>Go to beginning of next word</td>
<td>Ctrl + Right Arrow</td>
<td>Option + Right Arrow</td>
</tr>
<tr>
<td>Go to beginning of line break</td>
<td>Ctrl + Up Arrow</td>
<td>Cmd + Left Arrow</td>
</tr>
<tr>
<td>Go to end of line break</td>
<td>Ctrl + Down Arrow</td>
<td>Cmd + Right Arrow</td>   
</tr>    
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style="height:25px;"><strong>Text Selection</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>
<tr>
<td>Select characters to the left</td>
<td>Shift + Left Arrow</td>
<td>Shift + Left Arrow</td>
</tr>
<tr>
<td>Select characters to the right</td>
<td>Shift + Right Arrow</td>
<td>Shift + Right Arrow</td>
</tr>
<tr>
<td>Select lines upwards</td>
<td>Shift + Up Arrow</td>
<td>Shift + Up Arrow</td>
</tr>
<tr>
<td>Select lines downwards</td>
<td>Shift + Down Arrow</td>
<td>Shift + Down Arrow</td>
</tr>
<tr>
<td>Select words to the left</td>
<td>Shift + Ctrl + Left</td>
<td>Shift + Opt + Left</td>
</tr>
<tr>
<td>Select words to the right</td>
<td>Shift + Ctrl + Right</td>
<td>Shift + Opt + Right</td>
</tr>
<tr>
<td>Select paragraphs to the left</td>
<td>Shift + Ctrl + Up</td>
<td>Shift + Opt + Up</td>
</tr>
<tr>
<td>Select paragraphs to the right</td>
<td>Shift + Ctrl + Down</td>
<td>Shift + Opt + Down</td>
</tr>
<tr>
<td>Select text between the cursor and the beginning of the current line </td>
<td>Shift + Home</td>
<td>Cmd + Shift + Left Arrow</td>
</tr>
<tr>
<td>Select text between the cursor and the end of the current line</td>
<td>Shift + End</td>
<td>Cmd + Shift + Right Arrow</td>
</tr>
<tr>
<td>Select text between the cursor and the beginning of the document</td>
<td>Shift + Ctrl + Home</td>
<td>Cmd + Shift + Up Arrow or Cmd + Shift + Fn + Left Arrow</td>
</tr>
<tr>
<td>Select text between the cursor and the end of the document</td>
<td>Shift + Ctrl + End</td>
<td>Cmd + Shift + Down Arrow or Cmd + Shift + Fn + Right Arrow</td>
</tr>
<tr>
<td>Select one frame at a time of text above the cursor</td>
<td>Shift + Page Up</td>
<td>Shift + Fn + Up Arrow</td>
</tr>
<tr>
<td>Select one frame at a time of text below the cursor</td>
<td>Shift + Page Down</td>
<td>Shift + Fn + Down Arrow</td>
</tr>
<tr>
<td>Select all text</td>
<td>Ctrl + A</td>
<td>Cmd + A</td>
</tr>
<tr>
<td>Find text</td>
<td>Ctrl + F</td>
<td>Cmd + F</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style="height:25px;"><strong>Text Formatting</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>
<tr>
<td>Make selected text bold</td>
<td>Ctrl + B</td>
<td>Cmd + B</td>
</tr>
<tr>
<td>Make selected text italic</td>
<td>Ctrl + I</td>
<td>Cmd + I</td>
</tr>
<tr>
<td>Underline selected text</td>
<td>Ctrl + U</td>
<td>Cmd + U</td>
</tr>
<tr>
<td>Make selected text superscript</td>
<td>Ctrl + Shift + =</td>
<td>Cmd + Shift + =</td>
</tr>
<tr>
<td>Make selected text subscript</td>
<td>Ctrl + =</td>
<td>Cmd + =</td>
</tr> 
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style="height:25px;"><strong>Text Editing</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>
<tr>
<td>Delete characters to the left</td>
<td>Backspace</td>
<td>Backspace</td>
</tr>
<tr>
<td>Delete characters to the right</td>
<td>Delete</td>
<td>Fn + Backspace</td>
</tr>
<tr>
<td>Delete words to the right</td>
<td>Ctrl + Del</td>
<td>Cmd + Backspace</td>
</tr>  
<tr>
<td>Delete words to the left</td>
<td>Ctrl + Backspace</td>
<td>Cmd + Fn + Backspace</td>
</tr>
<tr>
<td>Indent</td>
<td>Tab</td>
<td>Tab</td>
</tr>
<tr>
<td>Outdent</td>
<td>Shift + Tab</td>
<td>Shift + Tab</td>
</tr>
<tr>
<td>Copy text</td>
<td>Ctrl + C</td>
<td>Cmd + C</td>
</tr>
<tr>
<td>Find and replace text</td>
<td>Ctrl + H</td>
<td>Cmd + F</td>
</tr> 
<tr>
<td>Paste text</td>
<td>Ctrl + V</td>
<td>Cmd + V</td>
</tr>
<tr>
<td>Cut text</td>
<td>Ctrl + X</td>
<td>Cmd + X</td>
</tr>
<tr>
<td>Redo text</td>
<td>Ctrl + Y</td>
<td>Shift + Cmd + Z </td>
</tr>
<tr>
<td>Undo text</td>
<td>Ctrl + Z</td>
<td>Cmd + Z</td>
</tr>
</table>
<hr>
<div style="overflow:auto;text-align:center">
<!-- MidContent -->
  <div id='div-gpt-ad-1493883843099-0' style="display: inline-block">
    <script>
    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1493883843099-0'); });
    </script>
  </div>  
</div>
<hr>

<h2>Web Browsers</h2>
<table class="w3-table-all notranslate">
<tr>
<th style="width:52%">Description</th>
<th style="width:24%">Windows</th>
<th style="width:24%">Mac OS</th>
</tr>
<tr>
<td style="height:25px;"><strong>Navigation</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>   
<tr>
<td>Scroll down a frame</td>
<td>Space or Page Down</td>
<td>Space or Fn + Down Arrow</td>
</tr>
<tr>
<td>Scroll up a frame</td>
<td>Shift + Space or Page Up</td>
<td>Shift + Space or Fn + Up Arrow</td>
</tr>
<tr>
<td>Go to bottom of the page</td>
<td>End</td>
<td>Cmd + Down Arrow</td>
</tr>
<tr>
<td>Go to top of the page </td>
<td>Home</td>
<td>Cmd + Up Arrow</td>
</tr>
<tr>
<td>Go back</td>
<td>Alt + Left Arrow or Backspace</td>
<td>Cmd + Left Arrow</td>
</tr>
<tr>
<td>Go forward</td>
<td>Alt + Right Arrow or Shift + Backspace</td>
<td>Cmd + Right Arrow</td>
</tr>
<tr>
<td>Refresh a webpage</td>
<td>F5</td>
<td>Cmd + R</td>
</tr>
<tr>
<td>Refresh a webpage (no cache)</td>
<td>Ctrl + F5</td>
<td>Cmd + Shift + R</td>
</tr>
<tr>
<td>Stop</td>
<td>Esc</td>
<td>Esc</td>
</tr>
<tr>
<td>Toggle full-screen</td>
<td>F11</td>
<td>Cmd + Shift + F</td>
</tr>
<tr>
<td>Zoom in</td>
<td>Ctrl + +</td>
<td>Cmd + +</td>
</tr>
<tr>
<td>Zoom out</td>
<td>Ctrl + -</td>
<td>Cmd + -</td>
</tr>
<tr>
<td>Zoom 100% (default)</td>
<td>Ctrl + 0</td>
<td>Cmd + 0</td>
</tr>
<tr>
<td>Open homepage</td>
<td>Alt + Home</td>
<td>Option + Home or Option + Fn + Left Arrow</td>
</tr>
<tr>
<td>Find text</td>
<td>Ctrl + F</td>
<td>Cmd + F </td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style="height:25px;"><strong>Tab / Window Management</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>
<tr>
<td>Open a new tab</td>
<td>Ctrl + T</td>
<td>Cmd + T</td>
</tr>
<tr>
<td>Close current tab</td>
<td>Ctrl + W</td>
<td>Cmd + W</td>
</tr>
<tr>
<td>Close all tabs</td>
<td>Ctrl + Shift + W</td>
<td>Cmd + Q</td>
</tr>
<tr>
<td>Close all tabs except the current tab</td>
<td>Ctrl + Alt + F4 </td>
<td>Cmd + Opt + W</td>
</tr>
<tr>
<td>Go to next tab</td>
<td>Ctrl + Tab</td>
<td>Control + Tab or Cmd + Shift + Right Arrow</td>
</tr>
<tr>
<td>Go to previous tab </td>
<td>Ctrl + Shift + Tab</td>
<td>Shift + Control + Tab or Cmd + Shift + Left Arrow</td>
</tr>
<tr>
<td>Go to a specific tab number </td>
<td>Ctrl + 1-8</td>
<td>Cmd + 1-8 </td>
</tr>
<tr>
<td>Go to the last tab</td>
<td>Ctrl + 9</td>
<td>Cmd + 9</td>
</tr>
<tr>
<td>Reopen the last closed tab</td>
<td>Ctrl + Shift + T</td>
<td>Cmd + Shift + T </td>
</tr>
<tr>
<td>Open a new window</td>  
<td>Ctrl + N</td>
<td>Cmd + N</td>
</tr>
<tr>
<td>Close current window</td>  
<td>Alt + F4</td>
<td>Cmd + W</td>
</tr>
<tr>
<td>Go to next window</td>
<td>Alt + Tab</td>
<td>Cmd + Tab</td>
</tr>
<tr>
<td>Go to previous window </td>
<td>Alt + Shift + Tab</td>
<td>Cmd + Shift + Tab</td>
</tr>
<tr>
<td>Reopen the last closed window</td>
<td>Ctrl + Shift + N</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>Open links in a new tab in the background</td>
<td>Ctrl + Click</td>
<td>Cmd + Click</td>
</tr>
<tr>
<td>Open links in a new tab in the foreground</td>
<td>Ctrl + Shift + Click</td>
<td>Cmd + Shift + Click</td>
</tr>
 <tr>
<td>Print current webpage</td>
<td>Ctrl + P</td>
<td>Cmd + P</td>
</tr>
<tr>
<td>Save current webpage</td>
<td>Ctrl + S</td>
<td>Cmd + S</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style="height:25px;"><strong>Address Bar</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>
<tr>
<td>Cycle between toolbar, search bar, and page elements</td>
<td>Tab</td>
<td>Tab</td>
</tr>
<tr>
<td>Go to browser's address bar</td>
<td>Ctrl + L or Alt + D</td>
<td>Cmd + L</td>
</tr>
<tr>
<td>Focus and select the browser's search bar</td>
<td>Ctrl + E</td>
<td>Cmd + E / Cmd + K</td>
</tr>
<tr>
<td>Open the address bar location in a new tab</td>
<td>Alt + Enter</td>
<td>Opt + Enter</td>
</tr>
<tr>
<td>Display a list of previously typed addresses</td>
<td>F4</td>
<td>&nbsp;</td>
</tr>
<tr>
<td>Add "www." to the beginning and ".com" to the end of the text typed in the 
address bar (e.g., type "w3schools" and press Ctrl + Enter to open "www.w3schools.com")</td>
<td>Ctrl + Enter</td>
<td>Cmd + Enter or Control + Enter</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style="height:25px;"><strong>Bookmarks</strong></td>
<td style="height:25px;"></td>
<td style="height:25px;"></td>
</tr>
<tr>
<td>Open the bookmarks menu</td>
<td>Ctrl + B</td>
<td>Cmd + B </td>
</tr>
<tr>
<td>Add bookmark for current page </td>
<td>Ctrl + D</td>
<td>Cmd + Opt + B or Cmd + Shift + B</td>
</tr>
<tr>
<td>Open browsing history</td>
<td>Ctrl + H</td>
<td>Cmd + Shift + H or Cmd + Y</td>
</tr>
<tr>
<td>Open download history</td>
<td>Ctrl + J</td>
<td>Cmd + J or Cmd + Shift + J </td>
</tr>
</table>

<h2>Screenshots</h2>
<table class="w3-table-all notranslate">
<tr>
<th style="width:52%">Description</th>
<th style="width:24%">Windows</th>
<th style="width:24%">Mac OS</th>
</tr>
<tr>
<td>Save screenshot of the whole screen as file</td>
<td>&nbsp;</td>
<td>Cmd + Shift + 3</td>
</tr>
<tr>
<td>Copy screenshot of the whole screen to the clipboard</td>
<td>PrtScr (Print Screen) or Ctrl + PrtScr</td>
<td>Cmd + Ctrl + Shift + 3</td>
</tr>
<tr>
<td>Save screenshot of window as file</td>
<td>&nbsp;</td>
<td>Cmd + Shift + 4, then Space</td>
</tr>
<tr>
<td>Copy screenshot of window to the clipboard</td>
<td>Alt + PrtScr</td>
<td>Cmd + Ctrl + Shift + 4, then Space</td>
</tr>
<tr>
<td style="height: 31px">Copy screenshot of wanted area to the clipboard</td>
<td style="height: 31px"></td>
<td style="height: 31px">Cmd + Ctrl + Shift + 4</td>
</tr>
<tr>
<td>Save screenshot of wanted area as file</td>
<td>&nbsp;</td>
<td>Cmd + Shift + 4</td>
</tr>
</table>
<br>
<p><b>Note:</b> Due to different keyboard setups, some shortcuts may not be compatible for all users.</p>
				<hr />
<div class="pre-btn">
<a href="com.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
				<div class="nxt-btn">
       <a href="third.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				</div>
				<?php include "sidebar_right.php" ?>
    
    </div>
    </div>

<?php include "foot.php" ?>