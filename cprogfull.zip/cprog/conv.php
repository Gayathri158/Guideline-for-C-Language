 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="bre.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="decbin.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div>
               <hr>
			   <h1> Convert in String</h1>
			   <h2>C program to count upper case, lower case and special characters in a string.</h2>
<p>In this program, we will count upper case, lower case and special characters. Logic behind to implement this program is too easy, just check characters is alphabet or not, if it is alphabet check for lower and upper case characters, if characters are not alphabets count them as special characters.
Program to count upper case, lower case and special characters in a string.</p>
<pre>
<code>
#include &lt;stdio.h&gt;
 int main()
{
    char text[100];
    int i;
    int countL,countU,countS;
     
    printf("Enter any string: ");
    gets(text);
 
    //here, we are printing string using printf
    //without using loop
    printf("Entered string is: %s\n",text);
     
    //count lower case, upper case and special characters
    //assign 0 to counter variables
    countL=countU=countS=0; 
     
    for(i=0;text[i]!='\0';i++)
    {
        //check for alphabet
        if((text[i]>='A' && text[i]<='Z') || (text[i]>='a' && text[i]<='z'))
        {
            if((text[i]>='A' && text[i]<='Z'))
            {
                //it is upper case alphabet
                countU++;
            }
            else
            {
                //it is lower case character
                countL++;
            }
        }
        else
        {
            //character is not an alphabet
            countS++; //it is special character
        }
    }
     
    //print values
    printf("Upper case characters: %d\n",countU);
    printf("Lower case characters: %d\n",countL);
    printf("Special characters: %d\n",countS);
     
    return 0;
}
</code>
</pre>
<h3>
Output</h3><pre>    
Enter any string: Hello Friends, I am Mike. 
    Entered string is: Hello Friends, I am Mike.
    Upper case characters: 4  
    Lower case characters: 15 
    Special characters: 6 
</pre>



<h2>C program to convert string in upper case and lower case.	</h2>

<p>In this program, we will convert string in upper case and lower case. First we will read a string and then convert string in upper case and after printing the string that is converted into upper case, we will convert it in lower case and print the lower case. 
Logic behind to implement this program - Just check the alphabets if they are in upper case add the value 32 [0x20 - hex value] to convert the character into lower case otherwise subtract 32 [0x20 - hex value] to convert the character into upper case. </p>

Because difference between in the ascii codes of upper case and lower case characters are 32 [0x20 - hex value].
	/*C program to convert string in upper case and lower case.*/
 <pre>
 <code>
#include &lt;stdio.h&gt;
int main()
{
    char text[100];
    int  i;
    printf("Enter any string: ");
    gets(text);
    printf("Entered string is: %s\n",text);
    //convert into upper case
    for(i=0;text[i]!='\0';i++)
    {
        if(text[i]>='a' && text[i]<='z')
            text[i]=text[i]-0x20;
    }
    printf("String in Upper case is: %s\n",text);   
    //convert into lower case
    for(i=0;text[i]!='\0';i++)
    {
        if(text[i]>='A' && text[i]<='Z')
            text[i]=text[i]+0x20;
    }
    printf("String in Lower case is: %s\n",text); 
    return 0;
}</code>
</pre>

<h3>Output   </h3>
<pre>
 Enter any string: Programming
    Entered string is: Programming
    String in Upper case is: PROGRAMMING
    String in Lower case is: programming
</pre>

<h2>C program to toggle case of all characters of string</h2>

<p>In this program, we will toggle all character’s case of string. 
Logic behind to implement this program is - Just convert lower case character in 
upper case and upper case character in lower case but first check that character 
is alphabet or not, if it is alphabet then do it.</p>
/*C program to toggle case of all characters of string.*/
 
<pre>
 <code>
#include &lt;stdio.h&gt;
 int main()
{
    char text[100];
    int i;
    printf("Enter any string: ");
    gets(text);
    printf("Entered string is: %s\n",text);
      //convert into upper case
    for(i=0;text[i]!='\0';i++)
    {
        //check character is alphabet or not
        if((text[i]>='A' && text[i]<='Z')||(text[i]>='a' && text[i]<='z'))
        {
            //check for upper case character
            if(text[i]>='A' && text[i]<='Z')
                text[i]=text[i]+0x20;
            else
                text[i]=text[i]-0x20;
        }
    }
      printf("String after toggle case: %s\n",text);
    return 0;
}
</code>
</pre>
 <h3>Output</h3>
 <pre>
Enter any string: your name
    Entered string is: your name
    String after toggle case: YOUR NAME
</pre>
				
				<hr />
<div class="pre-btn">
<a href="bre.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="decbin.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				 </div>
				 <?php include "sidebar_right.php" ?>
   
    </div>
    </div>

<?php include "foot.php" ?>