 <?php include "header.php" ?>
    <div class="row">
        <div class="content">
            <div class="col-md-7 middle-col">

                <hr>
                <div class="pre-btn">
                    <a href="table.php"><i
                                class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
                </div>
				<div class="nxt-btn">
       <a href="large.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <div class="clearer"></div>
               <hr>
<h1>Print Alphabet Triangle</h1>
<p>There are different triangles that can be printed. Triangles can be generated 
by alphabets or numbers. In this c program, we are going to print alphabet triangles.</p>
Let's see the c example to print alphabet triangle.
<pre>
<code>
#include &lt;stdio.h &gt;
#include &lt;conio.h &gt;    
void main(void)  
{  
    int ch=65;  
    int i,j,k,m;  
   clrscr();  
    for(i=1;i<=5;i++)  
    {  
        for(j=5;j>=i;j--)  
            printf(" ");  
        for(k=1;k<=i;k++)  
            printf("%c",ch++);  
            ch--;  
        for(m=1;m<i;m++)  
            printf("%c",--ch);  
        printf("\n");  
        ch=65;  
    }  
   getch();  
}</code>
</pre>  
<h3>Output:</h3>
<pre>
     A
    ABA
   ABCBA
  ABCDCBA
 ABCDEDCBA
</pre>
				<hr />
<div class="pre-btn">
<a href="table.php"><i class="icon icon-arrow-circle-o-left big-font"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="large.php">Next Page <i class="icon icon-arrow-circle-o-right big-font"></i>&nbsp;</a>
</div>

                <hr>
				 </div>
				 <?php include "sidebar_right.php" ?>
   
    </div>
    </div>

<?php include "foot.php" ?>